package api;

public class AlertaController {
    public String registrarAlerta(String cpf, double valor) {
        return "Alerta registrado para CPF " + cpf;
    }
}
