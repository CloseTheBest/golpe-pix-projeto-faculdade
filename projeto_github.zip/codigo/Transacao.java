package model;

public class Transacao {
    private String cpf;
    private double valor;
}
