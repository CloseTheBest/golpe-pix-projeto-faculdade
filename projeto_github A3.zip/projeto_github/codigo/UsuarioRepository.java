package com.seuprojeto.repository;

import com.seuprojeto.model.Usuario;
import org.springframework.stereotype.Repository;
import java.util.Optional;

// Repositório SIMULADO para demonstração
@Repository
public class UsuarioRepository {

    /**
     * @brief Simula a busca de um usuário no banco de dados.
     */
    public Optional<Usuario> findById(String id) {
        // Simulação de dados: Retorna um usuário mockado se o ID for conhecido.
        if ("user-123".equals(id)) {
            // Usuario com media 500.0, dispositivo principal "mobile-xyz"
            return Optional.of(new Usuario("user-123", 500.0, "mobile-xyz"));
        }
        return Optional.empty(); // Usuário não encontrado
    }
}