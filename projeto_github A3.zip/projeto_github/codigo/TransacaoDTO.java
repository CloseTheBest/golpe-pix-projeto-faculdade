package com.seuprojeto.dto;

public class TransacaoDTO {

    private String usuarioId;
    private double valor;
    private String destino;
    private String dispositivo;
    private String horario; // Formato string (ex: "HH:mm") para simplificar

    // Construtor, Getters e Setters (Essenciais para o funcionamento do DTO)

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getDispositivo() {
        return dispositivo;
    }

    public void setDispositivo(String dispositivo) {
        this.dispositivo = dispositivo;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
}