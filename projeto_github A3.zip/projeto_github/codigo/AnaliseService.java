package com.seuprojeto.service;

import com.seuprojeto.dto.ResultadoAnalise;
import com.seuprojeto.dto.TransacaoDTO;
import com.seuprojeto.model.Usuario;
import com.seuprojeto.repository.UsuarioRepository; // Simulação
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

@Service
public class AnaliseService {

    // Simulação da injeção de dependência do repositório
    @Autowired
    private UsuarioRepository usuarioRepository;

    public ResultadoAnalise processar(TransacaoDTO t) {
        // Busca o usuário no repositório (simulado)
        Usuario u = usuarioRepository.findById(t.getUsuarioId()).orElse(null);

        // Se o usuário não for encontrado (Risco máximo)
        if (u == null) {
            return new ResultadoAnalise(100, "Usuario nao encontrado");
        }

        int risco = 0;

        // Regra 1: valor muito acima da media historica (Aumenta o risco em 40 pontos)
        // Se o valor for 3x maior que a média histórica
        if (t.getValor() > u.getMediaValor() * 3) {
            risco += 40;
        }

        // Regra 2: horario incomum (ex: madrugada) (Aumenta o risco em 20 pontos)
        if (isHorarioSuspeito(t.getHorario())) {
            risco += 20;
        }

        // Regra 3: dispositivo desconhecido (Aumenta o risco em 30 pontos)
        if (!t.getDispositivo().equals(u.getDispositivo())) {
            risco += 30;
        }

        // Regra 4: destino incomum (Aumenta o risco em 10 pontos)
        if (!destinoFrequente(t.getDestino(), u)) {
            risco += 10;
        }
        
        // Garante que o risco não passe de 100
        risco = Math.min(risco, 100);

        return new ResultadoAnalise(risco, classificar(risco));
    }

    // Funções auxiliares (Omitidas no seu texto original)
    
    /**
     * @brief Regra 2: Verifica se o horário está fora do padrão (ex: 22h00 até 06h00).
     */
    private boolean isHorarioSuspeito(String horarioString) {
        // Converte a string "HH:mm" para LocalTime
        try {
            LocalTime horarioTransacao = LocalTime.parse(horarioString, DateTimeFormatter.ofPattern("HH:mm"));
            LocalTime inicioMadrugada = LocalTime.of(22, 0); // 22:00
            LocalTime fimMadrugada = LocalTime.of(6, 0);    // 06:00
            
            // Se o horário está entre 22:00 e 05:59:59.999...
            if (horarioTransacao.isAfter(inicioMadrugada.minusSeconds(1)) || horarioTransacao.isBefore(fimMadrugada)) {
                return true;
            }
            return false;
        } catch (Exception e) {
            // Tratar erro de formato, assumindo que é suspeito em caso de erro.
            return true;
        }
    }

    /**
     * @brief Regra 4: Verifica se o destino está na lista de destinos frequentes do usuário.
     */
    private boolean destinoFrequente(String destino, Usuario u) {
        // Verifica se o array de destinos frequentes do usuário contém o destino atual
        return Arrays.asList(u.getDestinosFrequentes()).contains(destino);
    }
    
    /**
     * @brief Função de Classificação de Risco (Seção 8.4)
     */
    private String classificar(int risco) {
        if (risco < 40) return "Transacao segura";
        if (risco < 70) return "Transacao suspeita - enviar alerta";
        return "Alto risco - exigir autenticacao extra";
    }
}