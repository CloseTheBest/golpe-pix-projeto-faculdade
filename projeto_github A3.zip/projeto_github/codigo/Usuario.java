package com.seuprojeto.model;

public class Usuario {
    
    private String id;
    private double mediaValor; // Média histórica
    private String dispositivo; // Dispositivo principal
    // Simulação de lista de destinos frequentes para a Regra 4
    private String[] destinosFrequentes = {"PixJoao", "PixMaria", "PixContaPropria"};

    // Construtor com valores simulados
    public Usuario(String id, double mediaValor, String dispositivo) {
        this.id = id;
        this.mediaValor = mediaValor;
        this.dispositivo = dispositivo;
    }

    // Getters
    public String getId() {
        return id;
    }

    public double getMediaValor() {
        return mediaValor;
    }

    public String getDispositivo() {
        return dispositivo;
    }

    public String[] getDestinosFrequentes() {
        return destinosFrequentes;
    }
}