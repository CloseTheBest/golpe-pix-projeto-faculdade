package com.seuprojeto.controller;

import com.seuprojeto.dto.ResultadoAnalise;
import com.seuprojeto.dto.TransacaoDTO;
import com.seuprojeto.service.AnaliseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/transacoes")
public class TransacaoController {

    @Autowired
    private AnaliseService analiseService;

    @PostMapping("/analisar")
    public ResponseEntity<ResultadoAnalise> analisar(@RequestBody TransacaoDTO dto) {
        // Logica para processar a requisicao
        ResultadoAnalise resultado = analiseService.processar(dto);

        // Retorna o resultado da analise
        return ResponseEntity.ok(resultado);
    }
}