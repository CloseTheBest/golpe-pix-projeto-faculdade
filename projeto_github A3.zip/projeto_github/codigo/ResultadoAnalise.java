package com.seuprojeto.dto;

public class ResultadoAnalise {
    
    private int risco;
    private String classificacao;

    public ResultadoAnalise(int risco, String classificacao) {
        this.risco = risco;
        this.classificacao = classificacao;
    }

    // Getters
    public int getRisco() {
        return risco;
    }

    public String getClassificacao() {
        return classificacao;
    }
}